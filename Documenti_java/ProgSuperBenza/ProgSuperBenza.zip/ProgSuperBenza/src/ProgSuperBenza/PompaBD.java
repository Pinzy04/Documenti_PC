package ProgSuperBenza;

public class PompaBD {
    private int benzina;
    private int diesel;
    PompaBD(){
        benzina = 2000;
        diesel = 2000;
    }
}

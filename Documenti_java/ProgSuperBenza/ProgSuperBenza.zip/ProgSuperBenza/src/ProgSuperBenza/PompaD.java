package ProgSuperBenza;

public class PompaD {
    private int diesel;
    PompaD(){
        diesel = 2000;
    }
}

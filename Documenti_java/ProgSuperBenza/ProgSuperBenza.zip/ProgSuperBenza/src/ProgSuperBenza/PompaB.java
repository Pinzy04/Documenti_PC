package ProgSuperBenza;

import java.util.*;

public class PompaB {
    private int benzina;
    PompaB(){
        benzina = 2000;
    }
}

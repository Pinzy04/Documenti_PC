Inserimento di un nuovo stato con utilizzo dei file;
Ricerca di uno stato;
Rimozione di uno stato;
Elenco ordinato per categoria e modo;
Eliminazione di tutti i file;
Bandiera(da completare).
